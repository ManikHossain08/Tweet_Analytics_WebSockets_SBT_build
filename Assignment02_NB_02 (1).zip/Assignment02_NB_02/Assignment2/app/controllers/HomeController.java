package controllers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.inject.Inject;
import static akka.pattern.PatternsCS.ask;
import actors.TimeActor;
import actors.UserActor;
import akka.actor.ActorRef;
import akka.actor.ActorSystem;
import akka.stream.Materializer;
import play.libs.streams.ActorFlow;
import play.mvc.Controller;
import play.mvc.Result;
import play.mvc.WebSocket;
import service.RealTwitterService;
import service.TwitterService;
import twitter4j.Query;
import twitter4j.QueryResult;
import twitter4j.ResponseList;
import twitter4j.Status;
import twitter4j.TwitterException;
import models.Tweet;
import models.*;



/**
 * This controller contains an action to handle HTTP requests
 * to the application's home page.
 */
public class HomeController extends Controller {

	private ActorSystem actorSystem;
	private Materializer materializer;
	private TwitterService twitterService = RealTwitterService.getInstance();
	private ActorRef timeActor;
	private final List<Hashtag> tweethashtags;
	private Map<String, Long> finalMap;
	/**
	 * this action is used to inject the TimeActor in the HomeController
	 * @param system system wraps the Actors 
	 * @param materializer materializer is a factory for stream execution engines, it is the thing that makes streams run
	 */
	@Inject
	public HomeController(ActorSystem system,Materializer materializer) {
		this.tweethashtags =  new ArrayList<>();
		this.finalMap = new LinkedHashMap<>();
		this.actorSystem = system;
		this.materializer = materializer;
		timeActor = actorSystem.actorOf(TimeActor.getProps(),"timeActor");
	}
	
	
    /**
     * An action that renders an HTML page with a welcome message.
     * The configuration in the <code>routes</code> file means that
     * this method will be called when the application receives a
     * <code>GET</code> request with a path of <code>/</code>.
     */
    public Result index() {
        return ok(views.html.index.render(request()));
    }
    /**
     * 
     * @return Websocket
     */
    public WebSocket ws() {
    	return WebSocket.Json.accept(request -> ActorFlow.actorRef(UserActor::getProps,actorSystem,materializer));
    }
    
    /**
	 * Takes the user screenname and fetch the user object and list of tweets for
	 * that user asynchronously
	 * 
	 * @param screenName
	 *            the users screenname
	 * @return user's profile and its recent posts as a completable future of type
	 *         <code>Result</code>
	 * @author Md Manik Hossain
	 */
	public CompletionStage<Result> getUser(final String screenName) {
		CompletableFuture<twitter4j.User> promiseUser;
		CompletableFuture<ResponseList<Status>> promiseRecentPost;

		promiseUser = CompletableFuture.supplyAsync(() -> {
			twitter4j.User user = null;
				user = twitterService.showUser(screenName);
				
			
			return user;
		});
		promiseRecentPost = CompletableFuture.supplyAsync(() -> {
			ResponseList<Status> recentPost = null;
			
				recentPost = twitterService.getUserTimeline(screenName);
		
			return recentPost;
		});

		

		
		return promiseUser.thenCombine(promiseRecentPost, (user, post) -> ok(views.html.userProfile.render(user, post)));
	}
	
	/**
	 * 
	 * @param hashtag
	 * @return will render to hashtag search page
	 */
	
	public CompletionStage<Result> getHashtag(String hashtag) {
		
				
			/*Hashtag h = new Hashtag();
			System.out.println("controller"+hashtag);
			List<Status> resultTweets ;
			resultTweets = twitterService.queryApi(hashtag);
			
			List<Hashtag> result = new ArrayList<>();*/
			
			CompletableFuture<List<Hashtag>> hts;
			hts = CompletableFuture.supplyAsync(() -> {
				return twitterService.queryApi(hashtag).stream().map(t -> new Hashtag(t.getUser().getName(), t.getText())).collect(Collectors.toList());
			});
			
			
			/*for(Status t : resultTweets) {
				
				h.setName(t.getUser().getName());
				h.setTweet(t.getText());
				
				
			}*/
			
			//result.add(h);
			//this.tweethashtags.add(h);
			//return ok(views.html.hashtag.render(result));
			return hts.thenApply(ht -> ok(views.html.hashtag.render(ht)));
	}
	
	public CompletionStage<Result> getWordLevelStats(String keyword) {
		
		CompletableFuture<Map<String, Long>> mapper;
		finalMap = new LinkedHashMap<>();
		mapper = CompletableFuture.supplyAsync(() -> {
			return twitterService.getWordLevelStats(keyword);
		});

		return mapper.thenApply(map -> ok(views.html.wordLevelStats.render(map)));
	 }
}
