package service;

import java.util.List;
import java.util.Map;

import twitter4j.HashtagEntity;
import twitter4j.ResponseList;
import twitter4j.Status;
import twitter4j.User;

/**
 * Twitter Service class interface
 * 
 * @author
 *
 */
public interface TwitterService {

	public List<Status> queryApi(String keyword);

	public User showUser(String screenName);

	public ResponseList<Status> getUserTimeline(String screenName);
	
	public HashtagEntity[] hashtag(List<Status> tweets);
	
	public Map<String, Long> getWordLevelStats(String keyword);
	
}
