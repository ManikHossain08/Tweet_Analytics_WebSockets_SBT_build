/**
 * 
 */
package service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.inject.Singleton;

import com.google.inject.Inject;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

import twitter4j.HashtagEntity;
import twitter4j.Query;
import twitter4j.QueryResult;
import twitter4j.ResponseList;
import twitter4j.Status;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.User;
import twitter4j.conf.ConfigurationBuilder;


/**
 * Real implementation of TwitterService
 * Calls the actual Twitter API
 * @author 
 *
 */
@Singleton
public class RealTwitterService implements TwitterService{
	
	private final Config config;
	
	private final Twitter twitter;
	
	private static final RealTwitterService instance=new RealTwitterService();
	@Inject
	private RealTwitterService() {
		config = ConfigFactory.load();

		ConfigurationBuilder cb = new ConfigurationBuilder();
		cb.setDebugEnabled(true).setOAuthConsumerKey(config.getString("CONSUMER_KEY"))
				.setOAuthConsumerSecret(config.getString("CONSUMER_SECRET"))
				.setOAuthAccessToken(config.getString("ACCESS_TOKEN"))
				.setOAuthAccessTokenSecret(config.getString("ACCESS_TOKEN_SECRET"));
		TwitterFactory tf = new TwitterFactory(cb.build());
		twitter = tf.getInstance();
	}
	
	/**
	 * 
	 * @return instance
	 */
	public static RealTwitterService getInstance() {
		return instance;
	}
	List<Status> tweets = null;
	
	/**
	 * @return tweets
	 */
	@Override
	public List<Status> queryApi(String keyword) {
		
		Query query = new Query(keyword);
		query.setCount(10);
		QueryResult result;
		try {
			result = twitter.search(query);
			tweets = result.getTweets();
			
			
		} catch (TwitterException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return tweets;
	}
	
	/**
	 * 
	 * @return user of particular tweets
	 */
	@Override
	public User showUser(String screenName) {
		User user = null;
		try {	
			user = twitter.showUser(screenName);
			
			
		} catch (TwitterException exp) {
		}
		
		return user;
	}
	
	/**
	 * 
	 * @return the list 
	 */
	@Override
	public ResponseList<Status> getUserTimeline(String screenName) {
		ResponseList<Status> list = null;
		try {
			list = twitter.getUserTimeline(screenName);
			
			
			
		} catch (TwitterException exp) {
		}
		
		return list;
	}
	
	/**
	 * 
	 * This method returns the array of hashtags
	 * @return hashtag
	 */
	@Override
	public HashtagEntity[] hashtag(List<Status> tweets) {
		
		
		HashtagEntity[] h = null; 
		
		//System.out.println("Tweets in real twitter"+tweets);
		
		
		for(Status t : tweets) {
			
			
			h = t.getHashtagEntities();
			//System.out.println("Array h"+h);
			
			for (HashtagEntity h1 : h) {
				
				String h2 = "#" + h1.getText();
				//System.out.println("hashtag"+h);
				//System.out.println("hashtag json"+h);
			}
			
		}
		return h;
	}
	
	@Override
	public Map<String, Long> getWordLevelStats(String keyword){
		Map<String, Long> finalMap = new LinkedHashMap<>();
		if(keyword.equals("")==false && keyword.equals("")==false) {
		      Query query = new Query(keyword);
		  	  int numberOfTweets = 250;
		  	  long lastID = Long.MAX_VALUE;
		  	  ArrayList<Status> tweets = new ArrayList<Status>();
		  	  List<Map<String, Long>> distinctWords = new ArrayList<Map<String, Long>>();
		  	  while (tweets.size () < numberOfTweets) {
		  	    if (numberOfTweets - tweets.size() > 1)
		  	      query.setCount(100);
		  	    else 
		  	      query.setCount(numberOfTweets - tweets.size());
		  	    try {
		  	      QueryResult result = twitter.search(query);
		  	      tweets.addAll(result.getTweets());
		  	      distinctWords = Stream.concat(distinctWords.parallelStream(), tweets.parallelStream()
		  	    	        .map(t -> Arrays.asList(t.getText().toLowerCase().split(" ")).parallelStream().collect(Collectors.groupingBy(
		                              Function.identity(), Collectors.counting()
		                      ))).collect(Collectors.toList()).parallelStream()).collect(Collectors.toList());
		  	      for (Status t: tweets) 
		  	        if(t.getId() < lastID) lastID = t.getId();
		  	    }

		  	    catch (TwitterException te) {
		  	    	System.out.println("Couldn't connect: " + te);
		  	    }; 
		  	    query.setMaxId(lastID-1);
		  	  }
		  	  	Optional<Map<String, Long>> tempMaps = distinctWords.stream().reduce((m1, m2) -> {
		            return Stream.concat(m1.entrySet().parallelStream(), m2.entrySet().parallelStream())
		                    .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
		                            (m1Num, m2Num) -> m1Num + m2Num));
			  	    });
			  	     
			  	    tempMaps.get().entrySet().parallelStream().sorted(Map.Entry.<String, Long>comparingByValue()
			                .reversed()).forEachOrdered(e -> finalMap.put(e.getKey(), e.getValue()));
			  	    //System.out.println(finalMap.entrySet());
	    	}
		if(finalMap.containsKey("rt"))
			finalMap.remove("rt");
		return finalMap;
	}
	
	
//	public HashtagEntity[] hashtag(String hashtag) {
//		
//		HashtagEntity[] h = null; 
//		for(Status t : tweets) {
//			
//			h = t.getHashtagEntities();
//			
//			
//		}
//		
//		
//		return h;
//		
//		
//	}
 	
	
}
