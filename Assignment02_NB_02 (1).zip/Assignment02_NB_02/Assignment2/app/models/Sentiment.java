package models;

public class Sentiment {

	private String tweetdata ;
	private int rating;
	
	/**
	 * 
	 * @param tweetdata
	 */
	public Sentiment(String tweetdata) {
		
		this.tweetdata = tweetdata;
		
	}

	/**
	 * 
	 * @return tweetdata
	 */
	public String getTweetdata() {
		return tweetdata;
	}

	/**
	 * 
	 * @param tweetdata to set tweetdata
	 */
	public void setTweetdata(String tweetdata) {
		this.tweetdata = tweetdata;
	}

	/**
	 * 
	 * @return rating
	 */
	public int getRating() {
		return rating;
	}

	/**
	 * 
	 * @param rating to set rating of sentiments
	 */
	public void setRating(int rating) {
		this.rating = rating;
	}
	
	
	
	
}
