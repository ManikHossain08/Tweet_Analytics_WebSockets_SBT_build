package models;

import twitter4j.HashtagEntity;

public class Hashtag {
	
	
	private String tweet;
	private String name;
	
	public Hashtag(String name, String tweet) {
		this.tweet = tweet;
		this.name = name;
	}
	/**
	 * 
	 * @return tweet
	 */
	public String getTweet() {
		return tweet;
	}
	
	/**
	 * 
	 * @param tweet tweet to be set
	 */
	public void setTweet(String tweet) {
		this.tweet = tweet;
	}
	
	/**
	 * 
	 * @return name
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * 
	 * @param name name to be set
	 */
	public void setName(String name) {
		this.name = name;
	}
	

}
