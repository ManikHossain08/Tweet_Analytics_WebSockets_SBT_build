package service;

import static org.junit.Assert.assertNotEquals;
import static play.inject.Bindings.bind;

import java.util.List;

import java.util.Map;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import models.User;
import play.Application;
import play.inject.guice.GuiceApplicationBuilder;
import play.test.Helpers;
import twitter4j.HashtagEntity;
import twitter4j.ResponseList;
import twitter4j.Status;
import twitter4j.TwitterException;

/**
 * Unit Test for Twitter Service class
 * @author 
 *
 */
public class TwitterServiceTest {

	private static Application testApp;
	TwitterService twitterservice = testApp.injector().instanceOf(TwitterService.class);

	@BeforeClass
	public static void initTestApp() {
		testApp = new GuiceApplicationBuilder()
				.overrides(bind(TwitterService.class).to(MockTwitterService.class)).build();

	}

	@Test
	public void testqueryApi() {
		List<Status> tweets = twitterservice.queryApi("messi");
		
		Status jsonObject = tweets.get(0);

		String res = jsonObject.toString();
		assertNotEquals("{\r\n" + " \"created_at\":\"Mon Dec 07 15:24:15 +0000 20\",\r\n"
				+ " \"id\": 85005744,\r\n" + " \"id_str\": \"85000625744\",\r\n"
				+ " \"text\": \"1/ Canada is beautiful  !nhttps://t.co/XweGngmxlP\",\r\n"
				+ " \"user\": {},  \r\n" + " \"entities\": {}\r\n" + "}}", res);
	}
	
//	@Test(expected = TwitterException.class)
//	public void testCaseWhereExceptionWillBeThrown() throws Exception {
//	    
//		List<Status> tweets = twitterservice.queryApi("messi");
//		
//		Status jsonObject = tweets.get(0);
//
//		String res = jsonObject.toString();
//		assertNotEquals("{\r\n" + " \"created_at\":\"Thu Apr 06 15:24:15 +0000 2017\",\r\n"
//				+ " \"id\": 850006245121695744,\r\n" + " \"id_str\": \"850006245121695744\",\r\n"
//				+ " \"text\": \"1/ Today we’re sharing our vision for the future of the Twitter API platform!nhttps://t.co/XweGngmxlP\",\r\n"
//				+ " \"user\": {},  \r\n" + " \"entities\": {}\r\n" + "}}", res);
//	}
//	
	
	
	
	
	
	
	
	
	@Test
	public void testshowUser() {
		twitter4j.User user = twitterservice.showUser("abc");
	
		
		//twitter4j.User testuser = user;
		
		//String userobject = user.toString();
		
		//String res = jsonObject.toString();
		assertNotEquals("{\r\n" + " \"created_at\":\"Mon Dec 07 15:24:15 +0000 20\",\r\n"
				+ " \"id\": 85005744,\r\n" + " \"id_str\": \"85000625744\",\r\n"
				+ " \"text\": \"1/ Canada is beautiful  !nhttps://t.co/XweGngmxlP\",\r\n"
				+ " \"user\": {},  \r\n" + " \"entities\": {}\r\n" + "}}", user);
	}

	

	@Test
	public void testgetuserTimeline() {
		
		ResponseList<Status> usertimeline = twitterservice.getUserTimeline("vasu");
		
		
		
//		Status userJson = usertimeline.get(0);
//		
//		String timeline = userJson.toString();
		
		assertNotEquals("{\r\n" + " \"created_at\":\"Mon Dec 07 15:24:15 +0000 20\",\r\n"
				+ " \"id\": 85005744,\r\n" + " \"id_str\": \"85000625744\",\r\n"
				+ " \"text\": \"1/ Canada is beautiful  !nhttps://t.co/XweGngmxlP\",\r\n"
				+ " \"user\": {},  \r\n" + " \"entities\": {}\r\n" + "}}", usertimeline);
	}
	
	
	
	@Test
	public void testhashtag() {
		
		List<Status> testhashtag = twitterservice.queryApi("tbt") ;
		
		HashtagEntity[] hashtag = twitterservice.hashtag(testhashtag);
		
		
		//String testhash = hashtag.toString();
		
		assertNotEquals("{\r\n" + " \"created_at\":\"Mon Dec 07 15:24:15 +0000 20\",\r\n"
				+ " \"id\": 85005744,\r\n" + " \"id_str\": \"85000625744\",\r\n"
				+ " \"text\": \"1/ Canada is beautiful  !nhttps://t.co/XweGngmxlP\",\r\n"
				+ " \"user\": {},  \r\n" + " \"entities\": {}\r\n" + "}}", hashtag);
	}
	
	@Test
	public void testwordlevelstats() {
		
		Map<String,Long> wordmap = twitterservice.getWordLevelStats("sam"); 
		
		assertNotEquals("{\r\n" + " \"created_at\":\"Mon Dec 07 15:24:15 +0000 20\",\r\n"
				+ " \"id\": 85005744,\r\n" + " \"id_str\": \"85000625744\",\r\n"
				+ " \"text\": \"1/ Canada is beautiful  !nhttps://t.co/XweGngmxlP\",\r\n"
				+ " \"user\": {},  \r\n" + " \"entities\": {}\r\n" + "}}", wordmap);
	}
	

	
	
	
	
	@AfterClass
	public static void stopTestApp() {
		Helpers.stop(testApp);
	}

}