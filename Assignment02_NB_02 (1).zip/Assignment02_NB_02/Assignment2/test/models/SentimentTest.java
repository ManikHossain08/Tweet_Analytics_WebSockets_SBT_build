package models;

import static org.junit.Assert.assertEquals;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import models.Sentiment;

public class SentimentTest {
	
	
	public static final String tweetdata = "vasu";
	public static final int rating = 10;
	
	
	static Sentiment sentiment;
	
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		sentiment = new Sentiment(tweetdata);
	}
	
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		sentiment = null;
	}
	
	@Before
	public void setUp() {
		sentiment.setTweetdata(tweetdata);
		sentiment.setRating(rating);
	}
	
	
	@Test
	public void testtweetdata() {
		assertEquals(tweetdata, (sentiment.getTweetdata()));
		
	}
	
	@Test
	public void testrating() {
		assertEquals(rating, (sentiment.getRating()));
		
	}


}
