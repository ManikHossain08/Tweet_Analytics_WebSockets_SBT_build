package models;

import static org.junit.Assert.assertEquals;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import twitter4j.HashtagEntity;
import models.Hashtag;

public class HashtagTest {
	
	
	public static final String name = "vasu";
	public static final String tweet = "Canada is beautiful country";
	
	
	static Hashtag hashtag;
	
	
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		hashtag = new Hashtag(name,tweet);
	}
	
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		hashtag = null;
	}
	
	@Before
	public void setUp() {
		hashtag.setName(name);
		hashtag.setTweet(tweet);
		
		
		
	}
	
	
	@Test
	public void testname() {
		assertEquals(name, (hashtag.getName()));
	}
	
	
	@Test
	public void testhashtag() {
		assertEquals(tweet, (hashtag.getTweet()));
	}
	
//	
}

