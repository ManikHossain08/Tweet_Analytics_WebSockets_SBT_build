package models;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.LinkedHashMap;



import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import twitter4j.HashtagEntity;

/***
 * Tests the SearchResults class
 * 
 * @author 
 *
 */
public class SearchResultsTest {

	public static final String keyword = "Bitcoin";
	public static final ArrayList<Tweet> list = new ArrayList<>();
	public static final HashtagEntity[] hashtag = null;
	public static final int sentiment = 5;
	public static final Map<String, Long> wordLevelStats = new LinkedHashMap<>();	
	static SearchResults searchResult;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {

		list.add(new Tweet("Jane", "BitCoin is going up!!!",null));
		list.add(new Tweet("anna", "Bitcoin is crap",null));
		searchResult = new SearchResults("anna",list,null,sentiment,wordLevelStats);
		
		searchResult.setKeyword(keyword);
		searchResult.setTweet(list);
		searchResult.setHashtag(hashtag);
		searchResult.setSentiment(sentiment);
		searchResult.setWordLevelStats(wordLevelStats);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		searchResult = null;
	}

	/**
	 * Test method for {@link models.SearchResults#getKeyword()}.
	 */

	
	@Test
	public void testKeyword() {
		assertEquals(keyword, (searchResult.getKeyword()));
	}

	
	/**
	 * Test method for {@link models.SearchResults#getTweet()}.
	 */

	@Test
	public void testListOfTweets() {
		for (int i = 0; i < list.size(); i++) {
			List<Tweet> list2 = searchResult.getTweet();
			assertTrue(list.equals(list2));
		}
	}
	
	
	@Test
	public void testHashtag() {
		assertEquals(hashtag, (searchResult.getHashtag()));
	}
	
	@Test
	public void testsentiment() {
		assertEquals(sentiment, (searchResult.getSentiment()));
	}
	
	@Test
	public void testconstructor() {
		
		searchResult = new SearchResults("anna",list,null,sentiment,wordLevelStats);
		assertEquals("anna", searchResult.getKeyword());
		
		
	}
	

}
