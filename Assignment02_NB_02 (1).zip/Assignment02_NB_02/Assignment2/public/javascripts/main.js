
$(document).ready(function() {
	var url = $("#webSocketData").data("ws-url");
	ws = new WebSocket(url);
	ws.onmessage = function(event) {
		message= JSON.parse(event.data);
		json = message.data;
		obj = JSON.parse(json);
		keyword = obj.keyword;
		hashtag = obj.hashtag;
		sentiment = obj.sentiment;
		
		console.log(hashtag);
		
		if ($('#'+keyword).length==0){
			createDiv(keyword);
		}
		updateDiv(keyword,obj.tweet,obj.hashtag,obj.sentiment);
	}

	$('#searchForm').on('submit', function(e) {
		e.preventDefault();
		console.log("capturing form submission");
		ws.send(JSON.stringify({
			keyword : $("#keyword").val()
		}));
		$("#keyword").val("");
	});

});

function updateDiv(keyword,tweet,hashtag,sentiment){
	$('#'+keyword).find('p').empty();
	
	var s ="";
	
	if(obj.sentiment>0){
		
		s = ":-)";
	}else if(obj.sentiment<0){
		
		s = ":-(";
	}else{
		
		s = ":-|";
	}
	
	
	var innerHtml="<a target='_blank' href='wordLevelStats?keyword="+keyword+"'>Get Word level stats</a><ol>";
	tweet.forEach( function(item) {
		var i;
		var text = "";
		for (i = 0; i < item.hashtag.length; i++) {
			  text +=  "<a target='_blank' href='hashtag?hashtag="+item.hashtag[i].text+"'>" +item.hashtag[i].text+"</a>";
			}
		innerHtml+="<li><a target='_blank' href='user?screenName="+item.screenName+"'>"+item.screenName+"</a><span>"+item.tweet+"</span>" +
		
		text
				
		 +
		 s
		 +
		"</li>";
		});
	innerHtml+="</ol>";
	
	$('#'+keyword).find('p').append(innerHtml);
	
}

function createDiv(keyword){
	$(".card").clone().attr('id', keyword).appendTo("#data");
	$('#'+keyword).show();
	$('#'+keyword).find('h4').text('Keyword: '+keyword);
	
}