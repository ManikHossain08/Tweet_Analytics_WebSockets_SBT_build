# Individual Task List

## Md Manik Hossain 
  a) User Profle: Create a web page containing all available prole information about a user, as well as
  the last 10 tweets of that user. This prole page must be hyperlinked with the user name from the
  tweets on the main search page.
  
## Samuel Vineeth   
  b) Tweet Words: For a search query (one or multiple keywords), display a word-level statistics for the
  250 latest tweets (less if fewer are available), counting all unique words in descending order (by
  frequency of the words). This statistics page must be hyperlinked from the search terms above the
  results. You must use the Java 8 Streams API to process the tweets.
## Vasu Dadhania    
  c) Hashtags: For a given hashtag (linked from the tweets in the search results), display the 10 latest
  tweets containing this hashtag, in the same format as the tweets on the main search page.
  
## Kunjal Kotadia
  d) Tweet Sentiment: Given a stream of (up to 250) tweets, determine if these tweets are overall happy
  ':-)', sad ':-(' or neutral ':-|'. This sentiment will be displayed on the main search page
  for each search query (see Figure 2). Process the stream of tweets, nding happy and sad words,
  emojis, and emoticons and counting them (create your own \happy/sad" lists). If a tweet contains 2
  more than 70% \happy" strings, return a happy sentiment :-), for more than 70% sad, return an
  unhappy emoticon :-(, otherwise a neutral one :-|. For a stream of tweets, compute the average
  of the individual tweets' results. You must use the Java 8 Streams API to process the tweets.



# play-java-forms-example

This example shows form processing and form helper handling in Play.

## How to run

Start the Play app:

```bash
sbt run
```

And open <http://localhost:9000/>

## Documentation

Please see <https://playframework.com/documentation/latest/JavaForms>.
